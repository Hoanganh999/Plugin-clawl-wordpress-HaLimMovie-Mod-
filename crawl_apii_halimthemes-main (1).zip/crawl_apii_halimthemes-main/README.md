# PLUGINS CRAWL APII
  - Test trên bản Halimthemes 5.5.4 Nulled

![Alt text](Screenshot-2023-04-08-141930.png?raw=true "Image Demo")

![Alt text](Screenshot-2023-04-08-141958.png?raw=true "Image Demo")

## CHANGELOGS
  - Update 13/04/2023
    + Fix định dạng trailer
  - Update 08/04/2023
    + Thêm chức năng crawl tự động
    + Cập nhật tải hình ảnh
  - Update 01/10/2022
    + Fix get data LocalStorage
    + Fix cào định dạng lẻ bộ phim hoạt hình
  - Update 28/09/2022
    + Thêm random timeout crawl mỗi phim
  - Update 11/09/2022
    + Bộ lọc crawl
    + Cập nhật phim lên trang chủ khi phim có cập nhật mới
    + Tự động sửa link play http - https khi crawl
